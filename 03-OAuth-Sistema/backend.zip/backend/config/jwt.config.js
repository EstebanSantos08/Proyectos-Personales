module.exports = {
    jwtSecret: "CLAVE_SEGURA_2025",
    jwtExpiration: "1h"
}
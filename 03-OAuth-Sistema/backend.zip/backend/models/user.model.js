const users = [
    {
        id: 1,
        username: "admin",
        password: "password1",
        nombreCompleto: "Admin",
        email: "admin@web.com"
    },
    {
        id: 2,
        username: "doris",
        password: "password2",
        nombreCompleto: "Doris",
        email: "doris@web.com"
    },
    {
        id: 3,
        username: "user3",
        password: "password3",
        nombreCompleto: "User 3",
        email: "user3@web.com"
    }
];

module.exports = { users };